package com.dicoding.politikpediaxml.data.response

import com.google.gson.annotations.SerializedName

data class DeleteDislikeCommentResponse(

	@field:SerializedName("message")
	val message: String? = null
)
