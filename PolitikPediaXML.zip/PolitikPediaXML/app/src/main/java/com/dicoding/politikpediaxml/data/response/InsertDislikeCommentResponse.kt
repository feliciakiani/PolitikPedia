package com.dicoding.politikpediaxml.data.response

import com.google.gson.annotations.SerializedName

data class InsertDislikeCommentResponse(

	@field:SerializedName("message")
	val message: String? = null
)
